package com.danganronpa;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

// ============================================================
//  DgnPlaceholders — PlaceholderAPI Expansion
//
//  Registers all %dgn_*% placeholders so TAB, scoreboards,
//  holograms, and any other plugin can display live game data.
//
//  AVAILABLE PLACEHOLDERS:
//
//  Per-player:
//    %dgn_ultimate%       → "Ultimate Pianist"
//    %dgn_role%           → "STUDENT" / "BLACKENED" / "GHOST"
//    %dgn_role_display%   → "◆ Student" / "★ Blackened" / "☆ Ghost"
//    %dgn_role_color%     → "&a" / "&c" / "&8"  (for TAB formatting)
//    %dgn_coins%          → "14"
//    %dgn_status%         → "Alive" / "Ghost"
//    %dgn_is_blackened%   → "true" / "false"
//
//  Global (same for all players):
//    %dgn_phase%          → "INVESTIGATION"
//    %dgn_phase_display%  → "&bINVESTIGATION" (coloured for display)
//    %dgn_countdown%      → "32:07"  (MM:SS)
//    %dgn_chapter%        → "2"
//    %dgn_alive%          → "5"  (living player count)
//    %dgn_hope%           → "12"
//    %dgn_despair%        → "4"
//    %dgn_hope_bar%       → a 10-char progress bar e.g. "■■■■■■■□□□"
//    %dgn_game_running%   → "true" / "false"
// ============================================================
public class DgnPlaceholders extends PlaceholderExpansion {

    private final CorePlugin plugin;

    public DgnPlaceholders(CorePlugin plugin) {
        this.plugin = plugin;
    }

    // ── Required PlaceholderExpansion overrides ───────────────
    @Override public @NotNull String getIdentifier() { return "dgn"; }
    @Override public @NotNull String getAuthor()     { return "DanganronpaCraft"; }
    @Override public @NotNull String getVersion()    { return "1.0"; }

    // Persist across PlaceholderAPI reloads so TAB always works
    @Override public boolean persist() { return true; }

    // ── Placeholder resolution ────────────────────────────────
    @Override
    public String onPlaceholderRequest(Player player, @NotNull String identifier) {

        // ── PER-PLAYER placeholders ───────────────────────────
        if (player != null) {
            switch (identifier) {

                case "ultimate" -> {
                    return plugin.getUltimate(player.getName());
                }

                case "role" -> {
                    return plugin.getRole(player.getName());
                }

                case "role_display" -> {
                    return switch (plugin.getRole(player.getName())) {
                        case "BLACKENED" -> "★ Blackened";
                        case "GHOST"     -> "☆ Ghost";
                        default          -> "◆ Student";
                    };
                }

                // Returns a legacy colour code string for TAB's text formatting
                case "role_color" -> {
                    return switch (plugin.getRole(player.getName())) {
                        case "BLACKENED" -> "&c";
                        case "GHOST"     -> "&8";
                        default          -> "&a";
                    };
                }

                case "coins" -> {
                    return String.valueOf(plugin.getCoins(player.getName()));
                }

                case "status" -> {
                    return "GHOST".equals(plugin.getRole(player.getName())) ? "Ghost" : "Alive";
                }

                case "is_blackened" -> {
                    return String.valueOf("BLACKENED".equals(plugin.getRole(player.getName())));
                }
            }
        }

        // ── GLOBAL placeholders (player param may be null) ────
        switch (identifier) {

            case "phase" -> {
                return plugin.getCurrentPhase();
            }

            case "phase_display" -> {
                return switch (plugin.getCurrentPhase()) {
                    case "INVESTIGATION" -> "&bINVESTIGATION";
                    case "NIGHTTIME"     -> "&4NIGHTTIME";
                    case "TRIAL"         -> "&5CLASS TRIAL";
                    case "MORNING"       -> "&eMorning";
                    default              -> "&7Waiting";
                };
            }

            case "countdown" -> {
                int total = plugin.getPhaseCountdown();
                if (total <= 0) return "--:--";
                int mins = total / 60;
                int secs = total % 60;
                return String.format("%02d:%02d", mins, secs);
            }

            case "chapter" -> {
                int ch = plugin.getChapterNumber();
                return ch > 0 ? String.valueOf(ch) : "—";
            }

            case "alive" -> {
                // Count players whose role is not GHOST
                long alive = org.bukkit.Bukkit.getOnlinePlayers().stream()
                    .filter(p -> !"GHOST".equals(plugin.getRole(p.getName())))
                    .count();
                return String.valueOf(alive);
            }

            case "hope" -> {
                return String.valueOf(plugin.getHopeScore());
            }

            case "despair" -> {
                return String.valueOf(plugin.getDespairScore());
            }

            // A 10-character visual bar: filled squares for hope, empty for despair
            case "hope_bar" -> {
                int hope    = plugin.getHopeScore();
                int despair = plugin.getDespairScore();
                int total   = hope + despair;
                if (total == 0) return "&7□□□□□□□□□□";
                int filled = Math.round(10f * hope / total);
                String bar = "&b" + "■".repeat(filled)
                           + "&4" + "□".repeat(10 - filled);
                return bar;
            }

            case "game_running" -> {
                return String.valueOf(plugin.isGameRunning());
            }
        }

        // Unknown placeholder — return null so PAPI leaves it as-is
        return null;
    }
}
