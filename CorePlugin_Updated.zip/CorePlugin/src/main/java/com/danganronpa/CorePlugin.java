package com.danganronpa;

// ============================================================
//  DanganronpaCraft - CorePlugin
//  The unified automatic game engine.
//
//  REPLACES: UltimatesPlugin.jar + AnnouncementsPlugin.jar
//
//  COVERS:
//  - Roles, Ultimates, Blackened assignment, Role Cards
//  - Monokuma PA announcements & personalised motives
//  - Automatic nighttime/morning chapter cycle with timer
//  - Monocoin currency (passive earning, physical items)
//  - MonoMono Machine (weighted random gacha prizes)
//  - Roulette Machine (gambling with Despair Spin)
//  - Coin Shop (fixed-price useful items)
//  - Live scoreboard HUD (phase, timer, coins, hope, role)
//  - Hope & Despair tracking
//  - Chapter management (/startchapter, /setchapter)
// ============================================================

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.*;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class CorePlugin extends JavaPlugin implements Listener {

    // --------------------------------------------------------
    // PLAYER DATA
    // --------------------------------------------------------
    private final Map<String, String> ultimates   = new HashMap<>();
    private final Map<String, String> roles       = new HashMap<>();
    private final Map<String, String> backstories = new HashMap<>();
    private final Map<String, Integer> coins      = new HashMap<>();
    private final Map<String, String>  motives    = new HashMap<>(); // ultimate -> motive

    // --------------------------------------------------------
    // GAME STATE
    // --------------------------------------------------------
    private int  hopeScore        = 0;
    private int  despairScore     = 0;
    private int  chapterNumber    = 0;
    private String currentPhase   = "WAITING"; // WAITING / MORNING / INVESTIGATION / NIGHTTIME / TRIAL
    private int  investigationMinutes = 45;
    private int  nightMinutes         = 30;
    private boolean gameRunning   = false;
    private boolean nightActive   = false;

    // Countdown in seconds — driven by a repeating task
    private int phaseCountdown = 0;

    // --------------------------------------------------------
    // MACHINE LOCATIONS (stored as "world,x,y,z")
    // --------------------------------------------------------
    private String monoMomoLocation  = null;
    private String rouletteLocation  = null;
    private String shopLocation      = null;

    // Track machine uses per player per chapter
    private final Map<String, Integer> monoUses     = new HashMap<>();
    private final Map<String, Integer> rouletteUses = new HashMap<>();

    // --------------------------------------------------------
    // SCOREBOARD — removed, TAB plugin handles display
    // --------------------------------------------------------

    // --------------------------------------------------------
    // PERSISTENCE
    // --------------------------------------------------------
    private File dataFile;
    private FileConfiguration dataConfig;

    // NamespacedKey for coin items
    private NamespacedKey coinKey;
    private NamespacedKey prizeKey;

    // Packet sender — connects to the Fabric client mod
    public DgnPackets packets;

    // --------------------------------------------------------
    // STARTUP
    // --------------------------------------------------------
    @Override
    public void onEnable() {
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        coinKey  = new NamespacedKey(this, "monocoin");
        prizeKey = new NamespacedKey(this, "prize_item");
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        setupScoreboard();
        // Register PlaceholderAPI expansion
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new DgnPlaceholders(this).register();
            getLogger().info("PlaceholderAPI expansion registered. All %dgn_*% placeholders live.");
        } else {
            getLogger().warning("PlaceholderAPI not found - install it for TAB integration.");
        }

        // Register all commands
        reg("startgame",      new StartGameCommand());
        reg("startchapter",   new StartChapterCommand());
        reg("setchapter",     new SetChapterCommand());
        reg("setultimate",    new SetUltimateCommand());
        reg("getultimate",    new GetUltimateCommand());
        reg("listplayers",    new ListPlayersCommand());
        reg("rolecard",       new RoleCardCommand());
        reg("b",              new BlackenedChatCommand());
        reg("announce",       new AnnounceCommand());
        reg("setmotive",      new SetMotiveCommand());
        reg("listmotives",    new ListMotivesCommand());
        reg("motive",         new MotiveCommand());
        reg("nighttime",      new NighttimeCommand());
        reg("morning",        new MorningCommand());
        reg("givecoin",       new GiveCoinCommand());
        reg("coins",          new CoinsCommand());
        reg("setmono",        new SetMonoCommand());
        reg("setroulette",    new SetRouletteCommand());
        reg("setshop",        new SetShopCommand());
        reg("hope",           new HopeCommand());
        reg("sethope",        new SetHopeCommand());
        reg("resetgame",      new ResetGameCommand());

        // Register plugin messaging channels (connects to Fabric mod)
        packets = new DgnPackets(this);
        packets.registerChannels();

        // Chapter timer countdown task — runs every second
        new BukkitRunnable() {
            @Override public void run() { tickChapterTimer(); }
        }.runTaskTimer(this, 20L, 20L);

        // Broadcast game state to Fabric mod every 5 seconds
        new BukkitRunnable() {
            @Override public void run() {
                if (!gameRunning) return;
                long alive = getServer().getOnlinePlayers().stream()
                    .filter(p -> !"GHOST".equals(roles.getOrDefault(p.getName(), "")))
                    .count();
                packets.broadcastGameState(currentPhase, phaseCountdown,
                    (int) alive, chapterNumber, hopeScore, despairScore);
                // Also refresh each player's personal state
                for (Player p : getServer().getOnlinePlayers()) {
                    packets.sendPlayerState(p,
                        roles.getOrDefault(p.getName(), "STUDENT"),
                        ultimates.getOrDefault(p.getName(), ""),
                        coins.getOrDefault(p.getName(), 0));
                }
            }
        }.runTaskTimer(this, 40L, 100L); // first run after 2s, then every 5s

        getLogger().info("DanganronpaCraft CorePlugin loaded. Hope's Peak Academy is open.");
    }

    private void reg(String name, CommandExecutor exec) {
        var cmd = getCommand(name);
        if (cmd != null) cmd.setExecutor(exec);
    }

    // --------------------------------------------------------
    // SHUTDOWN
    // --------------------------------------------------------
    @Override
    public void onDisable() {
        saveData();
        if (packets != null) packets.unregisterChannels();
        getLogger().info("DanganronpaCraft data saved.");
    }





    // ========================================================
    // SCOREBOARD — fully removed, TAB plugin handles display
    // Leaving empty stubs so no call sites break during cleanup
    // ========================================================
    private void setupScoreboard() { /* TAB handles this */ }
    private void updateScoreboard() { /* TAB handles this */ }

    // ========================================================
    // CHAPTER TIMER TICK — runs every second
    // ========================================================
    private void tickChapterTimer() {
        if (!gameRunning || phaseCountdown <= 0) return;
        phaseCountdown--;

        // 5-minute warning before night
        if (currentPhase.equals("INVESTIGATION") && phaseCountdown == 300) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.showTitle(Title.title(
                    Component.text("⚠ NIGHTTIME IN 5 MINUTES", NamedTextColor.RED),
                    Component.text("Prepare yourself.", NamedTextColor.GRAY)
                ));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 0.5f);
            }
        }

        // 1-minute warning
        if (currentPhase.equals("INVESTIGATION") && phaseCountdown == 60) {
            monokumaAnnounce("Upupu~ One minute until nighttime! I hope everyone is ready. Fufu~");
        }

        // Transition: Investigation → Nighttime
        if (currentPhase.equals("INVESTIGATION") && phaseCountdown == 0) {
            triggerNighttime(null);
        }

        // Transition: Nighttime → Morning
        if (currentPhase.equals("NIGHTTIME") && phaseCountdown == 0) {
            triggerMorning(null);
        }
    }

    // ========================================================
    // MACHINE INTERACTION — MonoMono, Roulette, Shop
    // ========================================================
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;
        Player player = event.getPlayer();
        Location loc  = event.getClickedBlock().getLocation();
        String locStr = blockLocStr(loc);

        if (locStr.equals(monoMomoLocation)) {
            event.setCancelled(true);
            handleMonoMono(player);
        } else if (locStr.equals(rouletteLocation)) {
            event.setCancelled(true);
            handleRoulette(player);
        } else if (locStr.equals(shopLocation)) {
            event.setCancelled(true);
            handleShop(player);
        }
    }

    // ────────────────────────────────────────────────────────
    // MONOMONO MACHINE
    // ────────────────────────────────────────────────────────
    private void handleMonoMono(Player player) {
        int uses = monoUses.getOrDefault(player.getName(), 0);
        if (uses >= 3) {
            player.sendMessage(mk("⚠ The MonoMono Machine has had enough of you today. Try again next chapter.", NamedTextColor.RED));
            return;
        }

        int playerCoins = coins.getOrDefault(player.getName(), 0);
        // Cost scales with use: 5, 10, 15
        int cost = (uses + 1) * 5;

        if (playerCoins < cost) {
            player.sendMessage(mk("⚠ You need " + cost + " Monocoins to use the MonoMono Machine. You have " + playerCoins + ".", NamedTextColor.RED));
            return;
        }

        // Deduct coins
        adjustCoins(player, -cost);
        monoUses.put(player.getName(), uses + 1);

        // Play spin sound
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 1.2f);

        // Weighted random prize selection
        Prize prize = rollMonoMono();

        // Give prize item
        ItemStack item = buildPrizeItem(prize);
        player.getInventory().addItem(item);

        // Announce
        player.sendMessage(Component.text("\n"));
        player.sendMessage(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", TextColor.fromHexString("#FFD700")));
        player.sendMessage(Component.text("  ★ MONOMONO MACHINE ★", TextColor.fromHexString("#FFD700")).decoration(TextDecoration.BOLD, true));
        player.sendMessage(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", TextColor.fromHexString("#FFD700")));
        player.sendMessage(Component.text("  Upupu~ You got: ", NamedTextColor.WHITE)
            .append(Component.text(prize.displayName, rarityColor(prize.rarity)).decoration(TextDecoration.BOLD, true)));
        player.sendMessage(Component.text("  Rarity: " + prize.rarity, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, true));
        player.sendMessage(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n", TextColor.fromHexString("#FFD700")));

        // Legendary prizes get a server announcement
        if (prize.rarity.equals("Legendary")) {
            Bukkit.broadcast(Component.text(
                "✦ " + player.getName() + " pulled a LEGENDARY prize from the MonoMono Machine: " + prize.displayName + "!",
                TextColor.fromHexString("#FFD700")).decoration(TextDecoration.BOLD, true));
        }

        saveData();
    }

    // ────────────────────────────────────────────────────────
    // ROULETTE MACHINE
    // ────────────────────────────────────────────────────────
    private void handleRoulette(Player player) {
        int uses = rouletteUses.getOrDefault(player.getName(), 0);
        if (uses >= 5) {
            player.sendMessage(mk("⚠ You've had your fun. The Roulette Machine refuses your coins.", NamedTextColor.RED));
            return;
        }

        int bet = 10; // Fixed bet
        int playerCoins = coins.getOrDefault(player.getName(), 0);
        if (playerCoins < bet) {
            player.sendMessage(mk("⚠ You need " + bet + " Monocoins to spin the roulette. You have " + playerCoins + ".", NamedTextColor.RED));
            return;
        }

        adjustCoins(player, -bet);
        rouletteUses.put(player.getName(), uses + 1);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HARP, 1f, 1.5f);

        // Roll
        double roll = Math.random() * 100;
        String result;
        int coinChange;
        String effect;

        if (roll < 3) {
            // JACKPOT (3%)
            result    = "§6§lJACKPOT — GOLD";
            coinChange = 30;
            effect    = "jackpot";
        } else if (roll < 13) {
            // BIG WIN (10%)
            result    = "§aBig Win";
            coinChange = 15;
            effect    = "win";
        } else if (roll < 33) {
            // SMALL WIN (20%)
            result    = "§2Small Win";
            coinChange = 5;
            effect    = "win";
        } else if (roll < 53) {
            // BREAK EVEN (20%)
            result    = "§7Break Even";
            coinChange = 0;
            effect    = "nothing";
        } else if (roll < 75) {
            // SMALL LOSS (22%)
            result    = "§cSmall Loss";
            coinChange = -5;
            effect    = "loss";
        } else if (roll < 90) {
            // BIG LOSS (15%)
            result    = "§4Big Loss";
            coinChange = -12;
            effect    = "loss";
        } else {
            // DESPAIR SPIN (10%) — lose everything
            result    = "§5§lDESPAIR SPIN";
            coinChange = -playerCoins; // lose ALL coins
            effect    = "despair";
        }

        // Adjust coins (floor at 0)
        int before = coins.getOrDefault(player.getName(), 0);
        int after  = Math.max(0, before + coinChange);
        coins.put(player.getName(), after);
        saveData();

        // Display
        player.sendMessage(Component.text("\n"));
        player.sendMessage(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.DARK_PURPLE));
        player.sendMessage(Component.text("  ♦ ROULETTE ♦", NamedTextColor.LIGHT_PURPLE).decoration(TextDecoration.BOLD, true));
        player.sendMessage(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.DARK_PURPLE));
        player.sendMessage(Component.text("  Result: " + result));
        if (coinChange > 0)
            player.sendMessage(mk("  +" + coinChange + " Monocoins! Balance: " + after, NamedTextColor.GREEN));
        else if (coinChange < 0)
            player.sendMessage(mk("  " + coinChange + " Monocoins. Balance: " + after, NamedTextColor.RED));
        else
            player.sendMessage(mk("  No change. Balance: " + after, NamedTextColor.GRAY));
        player.sendMessage(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n", NamedTextColor.DARK_PURPLE));

        // Special effects
        switch (effect) {
            case "jackpot" -> {
                player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1.2f);
                player.getWorld().strikeLightningEffect(player.getLocation());
                Bukkit.broadcast(Component.text(
                    "✦ " + player.getName() + " hit the JACKPOT on the Roulette Machine! +30 coins!",
                    TextColor.fromHexString("#FFD700")).decoration(TextDecoration.BOLD, true));
            }
            case "despair" -> {
                player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.BLINDNESS, 100, 0, false, false));
                player.playSound(player.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5f, 0.5f);
                Bukkit.broadcast(Component.text(
                    "☠ " + player.getName() + " hit the DESPAIR SPIN and lost everything. Upupu~",
                    NamedTextColor.DARK_PURPLE).decoration(TextDecoration.BOLD, true));
                addDespair(1);
            }
            case "win"  -> player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1f);
            case "loss" -> player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 0.8f);
        }
    }

    // ────────────────────────────────────────────────────────
    // COIN SHOP
    // ────────────────────────────────────────────────────────
    private void handleShop(Player player) {
        // Give the player a shop menu book
        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta meta  = (BookMeta) Objects.requireNonNull(book.getItemMeta());
        meta.setTitle("Despair Mart");
        meta.setAuthor("Monokuma");

        meta.addPages(Component.text()
            .append(Component.text("━━━━━━━━━━━━━━━\n", NamedTextColor.DARK_GRAY))
            .append(Component.text("DESPAIR MART\n", TextColor.fromHexString("#FFD700")).decoration(TextDecoration.BOLD, true))
            .append(Component.text("━━━━━━━━━━━━━━━\n\n", NamedTextColor.DARK_GRAY))
            .append(Component.text("Your coins: " + coins.getOrDefault(player.getName(), 0) + "\n\n", NamedTextColor.GOLD).decoration(TextDecoration.BOLD, true))
            .append(Component.text("To buy, type:\n/buy <item name>\n\n", NamedTextColor.BLACK))
            .append(Component.text("Items on next page.", NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, true))
            .build());

        meta.addPages(Component.text()
            .append(Component.text("ITEMS FOR SALE\n━━━━━━━━━━\n\n", NamedTextColor.DARK_RED).decoration(TextDecoration.BOLD, true))
            .append(Component.text("nightvision — 8c\n", NamedTextColor.BLACK))
            .append(Component.text("firstaid — 10c\n", NamedTextColor.BLACK))
            .append(Component.text("compass — 10c\n", NamedTextColor.BLACK))
            .append(Component.text("anonymoustip — 8c\n", NamedTextColor.BLACK))
            .append(Component.text("flare — 5c\n", NamedTextColor.BLACK))
            .append(Component.text("smokescreen — 8c\n", NamedTextColor.BLACK))
            .append(Component.text("sleepingdraught — 15c\n", NamedTextColor.BLACK))
            .append(Component.text("liedetector — 20c", NamedTextColor.BLACK))
            .build());

        book.setItemMeta(meta);
        player.getInventory().addItem(book);
        player.sendMessage(mk("📖 Despair Mart catalogue added to your inventory. Type /buy <item> to purchase.", TextColor.fromHexString("#FFD700")));
    }

    // Register /buy command separately
    // (registered in onEnable but handled here as inner class below)

    // ========================================================
    // PRIZE ROLLING SYSTEM
    // ========================================================
    private static class Prize {
        String displayName, rarity, description;
        Material material;
        Prize(String n, String r, String d, Material m) { displayName=n; rarity=r; description=d; material=m; }
    }

    private static final List<Prize> PRIZE_POOL = List.of(
        // Common (40%)
        new Prize("Monokuma Plushie",      "Common",    "Decorative. Monokuma approves.",                             Material.PAPER),
        new Prize("Protein Supplement",    "Common",    "Regeneration I for 30 seconds.",                            Material.SUGAR),
        new Prize("Monokuma Keyring",      "Common",    "Worthless trinket. Very common.",                           Material.GOLD_NUGGET),
        new Prize("Despair Candy",         "Common",    "Gives Slowness I for 10 seconds. A trick prize.",           Material.SWEET_BERRIES),
        // Uncommon (30%)
        new Prize("Clue Fragment",         "Uncommon",  "A vague written hint about a weapon spawn location.",       Material.MAP),
        new Prize("First Aid Kit",         "Uncommon",  "Heals 4 hearts instantly when right-clicked.",             Material.APPLE),
        new Prize("Blackout Bomb",         "Uncommon",  "Splash Blindness to nearby players for 5 seconds.",        Material.GLASS_BOTTLE),
        new Prize("Coin Bag",              "Uncommon",  "Instantly gives 8 Monocoins.",                             Material.GOLD_NUGGET),
        new Prize("Smoke Screen",          "Uncommon",  "Particle cloud at your location.",                         Material.FIRE_CHARGE),
        // Rare (20%)
        new Prize("Evidence Eraser",       "Rare",      "Destroys one evidence item at your feet. Investigation only.", Material.ENDER_EYE),
        new Prize("Immunity Pendant",      "Rare",      "Cancels one murder attempt. Single use.",                   Material.NETHER_STAR),
        new Prize("Speed Capsule",         "Rare",      "Speed II for 60 seconds.",                                 Material.FEATHER),
        new Prize("Poison Antidote",       "Rare",      "Immunity to poison weapons for this night.",               Material.GHAST_TEAR),
        // Very Rare (8%)
        new Prize("Forged Alibi",          "Very Rare", "An official-looking false alibi book.",                    Material.WRITTEN_BOOK),
        new Prize("The Joker",             "Very Rare", "Send one anonymous untraceable message to any player.",    Material.DRAGON_BREATH),
        new Prize("Murder Clue (False)",   "Very Rare", "False evidence that looks identical to real evidence.",    Material.PAPER),
        // Legendary (2%)
        new Prize("Escape Route Map",      "Legendary", "Reveals a weapon spawn and a secret passage location.",    Material.FILLED_MAP),
        new Prize("Second Chance",         "Legendary", "If wrongly executed, you return. One use ever.",           Material.TOTEM_OF_UNDYING)
    );

    private Prize rollMonoMono() {
        double roll = Math.random() * 100;
        String rarity;
        if      (roll < 40) rarity = "Common";
        else if (roll < 70) rarity = "Uncommon";
        else if (roll < 90) rarity = "Rare";
        else if (roll < 98) rarity = "Very Rare";
        else                rarity = "Legendary";

        List<Prize> pool = PRIZE_POOL.stream().filter(p -> p.rarity.equals(rarity)).toList();
        return pool.get(new Random().nextInt(pool.size()));
    }

    private ItemStack buildPrizeItem(Prize prize) {
        ItemStack item = new ItemStack(prize.material);
        ItemMeta meta  = Objects.requireNonNull(item.getItemMeta());
        meta.displayName(Component.text(prize.displayName, rarityColor(prize.rarity)).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text(prize.description, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, true));
        lore.add(Component.text(" "));
        lore.add(Component.text("Rarity: " + prize.rarity, rarityColor(prize.rarity)).decoration(TextDecoration.ITALIC, true));
        lore.add(Component.text("MonoMono Prize", NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, true));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(prizeKey, org.bukkit.persistence.PersistentDataType.STRING, prize.displayName);
        // Apply immediate effects for certain prizes
        meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    private TextColor rarityColor(String rarity) {
        return switch (rarity) {
            case "Common"    -> NamedTextColor.GRAY;
            case "Uncommon"  -> NamedTextColor.GREEN;
            case "Rare"      -> NamedTextColor.AQUA;
            case "Very Rare" -> NamedTextColor.LIGHT_PURPLE;
            case "Legendary" -> TextColor.fromHexString("#FFD700");
            default          -> NamedTextColor.WHITE;
        };
    }

    // ========================================================
    // NIGHTTIME / MORNING HELPERS
    // ========================================================
    private void triggerNighttime(CommandSender sender) {
        currentPhase   = "NIGHTTIME";
        nightActive    = true;
        phaseCountdown = nightMinutes * 60;

        for (World world : Bukkit.getWorlds()) {
            world.setTime(13000);
            world.setStorm(false);
        }
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.BLINDNESS, 99999, 0, false, false));
            p.playSound(p.getLocation(), Sound.AMBIENT_CAVE, 1f, 0.5f);
        }
        monokumaAnnounce("Upupu~ It is now nighttime! As a reminder — committing murder is now permitted. Sweet dreams, and try not to die!");
        if (sender instanceof Player p) p.sendMessage(mk("[ADMIN] Nighttime activated.", NamedTextColor.GOLD));
    }

    private void triggerMorning(CommandSender sender) {
        currentPhase   = "MORNING";
        nightActive    = false;
        phaseCountdown = 0;

        for (World world : Bukkit.getWorlds()) world.setTime(1000);
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.removePotionEffect(org.bukkit.potion.PotionEffectType.BLINDNESS);
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HARP, 0.8f, 1.2f);
            // Survivor coin payout
            adjustCoins(p, 3);
        }
        monokumaAnnounce("Good morning, everyone! It is now 7AM. Nighttime is officially over. If a body has been discovered, please report it immediately!");
        if (sender instanceof Player p) p.sendMessage(mk("[ADMIN] Morning activated. +3 coins paid to all survivors.", NamedTextColor.GOLD));
    }

    // ========================================================
    // COIN HELPERS
    // ========================================================
    public void adjustCoins(Player player, int amount) {
        int current = coins.getOrDefault(player.getName(), 0);
        int updated = Math.max(0, current + amount);
        coins.put(player.getName(), updated);
        // Push updated coin total to the Fabric mod (shows in HUD top-right and Handbook)
        packets.sendPlayerState(player,
            roles.getOrDefault(player.getName(), "STUDENT"),
            ultimates.getOrDefault(player.getName(), ""),
            updated);
        // Also keep action bar as fallback for players without the mod
        if (amount > 0)
            player.sendActionBar(Component.text("+" + amount + " ✦  " + updated + " total", TextColor.fromHexString("#FFD700")));
        else if (amount < 0)
            player.sendActionBar(Component.text(amount + " ✦  " + updated + " remaining", NamedTextColor.RED));
        saveData();
    }

    // ========================================================
    // HOPE / DESPAIR HELPERS
    // ========================================================
    public void addHope(int amount) {
        hopeScore += amount;
        saveData();
        broadcastHopeChange(amount, true);
    }
    public void addDespair(int amount) {
        despairScore += amount;
        saveData();
        broadcastHopeChange(amount, false);
    }
    private void broadcastHopeChange(int amount, boolean hope) {
        String label = hope ? "§bHOPE" : "§cDESPAIR";
        String sign  = hope ? "+" : "+";
        Bukkit.broadcast(Component.text(
            " " + label + " " + sign + amount + "  §7(Hope: " + hopeScore + " | Despair: " + despairScore + ")"
        ));
    }

    // ========================================================
    // MONOKUMA BROADCAST HELPER
    // ========================================================
    public void monokumaAnnounce(String message) {
        // Chat broadcast (visible to all including non-mod players)
        Bukkit.broadcast(Component.text(""));
        Bukkit.broadcast(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.DARK_GRAY));
        Bukkit.broadcast(Component.text("  ★ MONOKUMA  ★  ", NamedTextColor.WHITE).decoration(TextDecoration.BOLD, true));
        Bukkit.broadcast(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.DARK_GRAY));
        Bukkit.broadcast(Component.text("  " + message, NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, true));
        Bukkit.broadcast(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n", NamedTextColor.DARK_GRAY));
        // Sound
        for (Player p : Bukkit.getOnlinePlayers())
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 0.5f);
        // Push to Fabric mod — shows the Monokuma notification widget
        if (packets != null) packets.broadcastMonokumaAnnounce(message);
    }

    // ========================================================
    // PLAYER JOIN — restore display
    // ========================================================
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (ultimates.containsKey(player.getName()))
            updateTabDisplay(player, ultimates.get(player.getName()), roles.getOrDefault(player.getName(), "STUDENT"));
        if (!coins.containsKey(player.getName())) {
            coins.put(player.getName(), 5);
            saveData();
        }
        // Send current state to the Fabric mod client
        if (gameRunning) {
            long alive = getServer().getOnlinePlayers().stream()
                .filter(p -> !"GHOST".equals(roles.getOrDefault(p.getName(), ""))).count();
            packets.broadcastGameState(currentPhase, phaseCountdown,
                (int) alive, chapterNumber, hopeScore, despairScore);
            packets.sendPlayerState(player,
                roles.getOrDefault(player.getName(), "STUDENT"),
                ultimates.getOrDefault(player.getName(), ""),
                coins.getOrDefault(player.getName(), 0));
        }
    }

    // ========================================================
    // TAB DISPLAY HELPER
    // ========================================================
    public void updateTabDisplay(Player player, String ultimate, String role) {
        String teamName = "dgn_" + player.getName();
        var scoreboard  = getServer().getScoreboardManager().getMainScoreboard();
        if (scoreboard.getTeam(teamName) != null)
            Objects.requireNonNull(scoreboard.getTeam(teamName)).unregister();
        var team = scoreboard.registerNewTeam(teamName);
        team.prefix(Component.text("✦ " + ultimate + " ", TextColor.fromHexString("#FFD700")).decoration(TextDecoration.ITALIC, false));
        team.color(NamedTextColor.WHITE);
        team.addPlayer(player);
    }

    // ========================================================
    // ROLE CARD HELPER
    // ========================================================
    public void giveRoleCard(Player player, String ultimate, String role, String backstory) {
        // Push profile data to the Fabric mod — shows in Handbook Profile tab
        packets.sendPlayerState(player, role, ultimate, coins.getOrDefault(player.getName(), 0));

        // Role reveal — big title on screen instead of a book
        String titleText    = "BLACKENED".equals(role) ? "★ THE BLACKENED ★" : "◆ STUDENT ◆";
        String subtitleText = "BLACKENED".equals(role)
            ? "Find a weapon. Commit the perfect murder."
            : ultimate + " — open H for your Handbook";
        net.kyori.adventure.text.format.TextColor titleCol = "BLACKENED".equals(role)
            ? TextColor.fromHexString("#CC0000")
            : TextColor.fromHexString("#FFD700");

        player.showTitle(Title.title(
            Component.text(titleText, titleCol).decoration(TextDecoration.BOLD, true),
            Component.text(subtitleText, NamedTextColor.WHITE),
            Title.Times.times(
                java.time.Duration.ofMillis(500),
                java.time.Duration.ofMillis(3500),
                java.time.Duration.ofMillis(1000)
            )
        ));

        // Blackened gets a follow-up private message
        if ("BLACKENED".equals(role)) {
            player.sendMessage(mk("★ You are the Blackened. Your role is in H → Profile. Use /b to speak secretly.", TextColor.fromHexString("#CC0000")));
        } else {
            player.sendMessage(mk("◆ Press H to open your E-Handbook and view your profile, evidence, and coins.", TextColor.fromHexString("#FFD700")));
        }
    }

    // ========================================================
    // UTILITY
    // ========================================================
    private Component mk(String text, TextColor color) {
        return Component.text(text, color);
    }
    private String blockLocStr(Location loc) {
        if (loc.getWorld() == null) return "";
        return loc.getWorld().getName() + "," + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ();
    }

    // ========================================================
    // COMMANDS
    // ========================================================

    // ─── /startgame ─────────────────────────────────────────
    class StartGameCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player admin)) { sender.sendMessage("Must be a player."); return true; }
            List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
            if (players.isEmpty()) { admin.sendMessage(mk("⚠ You need to be online to start the game.", NamedTextColor.RED)); return true; }

            // Solo mode — assign the lone player as STUDENT so they can test everything.
            // Run /startgame again with 2+ players for a real game where Blackened is random.
            Player blackened = null;
            if (players.size() == 1) {
                admin.sendMessage(mk("⚠ Solo test mode: You are assigned STUDENT. Add a second player for a real Blackened assignment.", NamedTextColor.GOLD));
            } else {
                blackened = players.get(new Random().nextInt(players.size()));
            }
            roles.clear();
            for (Player p : players) {
                String role = (blackened != null && p.equals(blackened)) ? "BLACKENED" : "STUDENT";
                roles.put(p.getName(), role);
                if (role.equals("BLACKENED")) p.addScoreboardTag("blackened");
                else p.removeScoreboardTag("blackened");
                if (!ultimates.containsKey(p.getName())) ultimates.put(p.getName(), "Ultimate ???");
                if (!backstories.containsKey(p.getName())) backstories.put(p.getName(), "Your past is shrouded in mystery. Even you cannot remember how you arrived at Hope's Peak Academy.");
                if (!coins.containsKey(p.getName())) coins.put(p.getName(), 5);
            }
            for (Player p : players) {
                giveRoleCard(p, ultimates.get(p.getName()), roles.get(p.getName()), backstories.get(p.getName()));
                updateTabDisplay(p, ultimates.get(p.getName()), roles.get(p.getName()));
                // Send initial state to Fabric mod
                packets.sendPlayerState(p, roles.get(p.getName()), ultimates.get(p.getName()), coins.get(p.getName()));
            }
            if (blackened != null) {
                blackened.sendMessage(mk("\n★ YOU ARE THE BLACKENED ★\nFind a weapon in the school and commit a murder.\nUse /b to speak privately.\nDo not get caught.\n", NamedTextColor.DARK_RED));
            }
            gameRunning    = true;
            chapterNumber  = 1;
            currentPhase   = "MORNING";

            Bukkit.broadcast(mk("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", TextColor.fromHexString("#FFD700")));
            Bukkit.broadcast(Component.text("  ★  WELCOME TO HOPE'S PEAK ACADEMY  ★", TextColor.fromHexString("#FFD700")).decoration(TextDecoration.BOLD, true));
            Bukkit.broadcast(mk("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", TextColor.fromHexString("#FFD700")));
            Bukkit.broadcast(mk("  Check your inventory for your Role Card.", NamedTextColor.WHITE));
            Bukkit.broadcast(mk("  " + players.size() + " students are trapped. The killing game begins now.", NamedTextColor.GRAY));
            Bukkit.broadcast(mk("  Earn Monocoins. Use the machines. Stay alive.\n", NamedTextColor.GRAY));

            saveData();
            String blackenedName = blackened != null ? blackened.getName() : "None (solo test)";
            admin.sendMessage(mk("[ADMIN] Game started. Blackened: " + blackenedName, NamedTextColor.GOLD));
            return true;
        }
    }

    // ─── /startchapter ──────────────────────────────────────
    class StartChapterCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            currentPhase   = "INVESTIGATION";
            phaseCountdown = investigationMinutes * 60;
            monoUses.clear();
            rouletteUses.clear();
            if (chapterNumber == 0) chapterNumber = 1;
            else chapterNumber++;

            // Give all living players chapter start coin bonus
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!"GHOST".equals(roles.getOrDefault(p.getName(), "")))
                    adjustCoins(p, 1);
            }

            monokumaAnnounce("Chapter " + chapterNumber + " has begun! The investigation phase is now open. You have " + investigationMinutes + " minutes before nighttime. Upupu~");
            sender.sendMessage(mk("[ADMIN] Chapter " + chapterNumber + " started. Investigation: " + investigationMinutes + " min. Night: " + nightMinutes + " min.", NamedTextColor.GOLD));
            return true;
        }
    }

    // ─── /setchapter <inv_min> <night_min> ──────────────────
    class SetChapterCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (args.length < 2) { sender.sendMessage(mk("Usage: /setchapter <investigation_minutes> <night_minutes>", NamedTextColor.RED)); return true; }
            try {
                investigationMinutes = Integer.parseInt(args[0]);
                nightMinutes         = Integer.parseInt(args[1]);
                sender.sendMessage(mk("[ADMIN] Chapter timer set: Investigation=" + investigationMinutes + "min, Night=" + nightMinutes + "min.", NamedTextColor.GREEN));
            } catch (NumberFormatException e) {
                sender.sendMessage(mk("⚠ Both values must be numbers.", NamedTextColor.RED));
            }
            return true;
        }
    }

    // ─── /nighttime ─────────────────────────────────────────
    class NighttimeCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            triggerNighttime(sender); return true;
        }
    }

    // ─── /morning ───────────────────────────────────────────
    class MorningCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            triggerMorning(sender); return true;
        }
    }

    // ─── /announce <message> ────────────────────────────────
    class AnnounceCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (args.length == 0) { sender.sendMessage(mk("Usage: /announce <message>", NamedTextColor.RED)); return true; }
            monokumaAnnounce(String.join(" ", args));
            return true;
        }
    }

    // ─── /setultimate <player> <title> ──────────────────────
    class SetUltimateCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (args.length < 2) { sender.sendMessage(mk("Usage: /setultimate <player> <ultimate>", NamedTextColor.RED)); return true; }
            String targetName = args[0];
            String ultimate   = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
            ultimates.put(targetName, ultimate);
            saveData();
            Player t = Bukkit.getPlayer(targetName);
            if (t != null) {
                updateTabDisplay(t, ultimate, roles.getOrDefault(targetName, "STUDENT"));
                t.sendMessage(mk("✦ Your Ultimate has been set: " + ultimate, TextColor.fromHexString("#FFD700")));
            }
            sender.sendMessage(mk("[ADMIN] Set " + targetName + "'s Ultimate to: " + ultimate, NamedTextColor.GREEN));
            return true;
        }
    }

    // ─── /getultimate <player> ──────────────────────────────
    class GetUltimateCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (args.length < 1) { sender.sendMessage(mk("Usage: /getultimate <player>", NamedTextColor.RED)); return true; }
            String name = args[0];
            sender.sendMessage(mk("━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GRAY));
            sender.sendMessage(mk("Player: ", NamedTextColor.GOLD).append(mk(name, NamedTextColor.WHITE)));
            sender.sendMessage(mk("Ultimate: ", NamedTextColor.GOLD).append(mk(ultimates.getOrDefault(name, "Not set"), NamedTextColor.WHITE)));
            sender.sendMessage(mk("Role: ", NamedTextColor.GOLD).append(mk(roles.getOrDefault(name, "Not assigned"),
                "BLACKENED".equals(roles.get(name)) ? NamedTextColor.RED : NamedTextColor.GREEN)));
            sender.sendMessage(mk("Coins: ", NamedTextColor.GOLD).append(mk(String.valueOf(coins.getOrDefault(name, 0)), NamedTextColor.YELLOW)));
            sender.sendMessage(mk("━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GRAY));
            return true;
        }
    }

    // ─── /listplayers ───────────────────────────────────────
    class ListPlayersCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            sender.sendMessage(mk("━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GOLD));
            sender.sendMessage(Component.text("  DANGANRONPA PLAYER LIST", NamedTextColor.GOLD).decoration(TextDecoration.BOLD, true));
            sender.sendMessage(mk("━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GOLD));
            if (ultimates.isEmpty()) { sender.sendMessage(mk("  No players yet.", NamedTextColor.GRAY)); }
            else {
                for (Map.Entry<String, String> e : ultimates.entrySet()) {
                    String n = e.getKey(), u = e.getValue(), r = roles.getOrDefault(n, "?");
                    boolean online = Bukkit.getPlayer(n) != null;
                    sender.sendMessage(Component.text(online ? "● " : "○ ", online ? NamedTextColor.GREEN : NamedTextColor.GRAY)
                        .append(mk(n, NamedTextColor.WHITE))
                        .append(mk(" — " + u + " ", NamedTextColor.YELLOW))
                        .append(mk("[" + r + "]", "BLACKENED".equals(r) ? NamedTextColor.RED : NamedTextColor.DARK_GREEN))
                        .append(mk(" ✦" + coins.getOrDefault(n, 0), TextColor.fromHexString("#FFD700"))));
                }
            }
            sender.sendMessage(mk("━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GOLD));
            return true;
        }
    }

    // ─── /rolecard ──────────────────────────────────────────
    class RoleCardCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
            if (!ultimates.containsKey(p.getName())) {
                p.sendMessage(mk("⚠ No role assigned yet. Wait for /startgame.", NamedTextColor.RED));
                return true;
            }
            // Re-push profile data to the mod and show a reminder
            packets.sendPlayerState(p,
                roles.getOrDefault(p.getName(), "STUDENT"),
                ultimates.getOrDefault(p.getName(), ""),
                coins.getOrDefault(p.getName(), 0));
            p.sendMessage(mk("◆ Press H to open your E-Handbook — Profile tab has your role card.", TextColor.fromHexString("#FFD700")));
            return true;
        }
    }

    // ─── /b <message> ───────────────────────────────────────
    class BlackenedChatCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player player)) return true;
            if (!"BLACKENED".equals(roles.get(player.getName()))) { player.sendMessage(mk("⚠ You are not the Blackened.", NamedTextColor.RED)); return true; }
            if (args.length == 0) { player.sendMessage(mk("Usage: /b <message>", NamedTextColor.RED)); return true; }
            Component msg = Component.text("☠ [BLACKENED] ", NamedTextColor.DARK_RED).decoration(TextDecoration.BOLD, true)
                .append(mk(player.getName() + ": ", NamedTextColor.RED))
                .append(mk(String.join(" ", args), NamedTextColor.RED).decoration(TextDecoration.ITALIC, true));
            for (Player p : Bukkit.getOnlinePlayers())
                if ("BLACKENED".equals(roles.get(p.getName())) || p.isOp()) p.sendMessage(msg);
            return true;
        }
    }

    // ─── /setmotive <ultimate> | <motive> ───────────────────
    class SetMotiveCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (args.length < 2) { sender.sendMessage(mk("Usage: /setmotive <ultimate> | <motive>", NamedTextColor.RED)); return true; }
            String[] parts = String.join(" ", args).split("\\|", 2);
            if (parts.length < 2) { sender.sendMessage(mk("Missing | separator!", NamedTextColor.RED)); return true; }
            motives.put(parts[0].trim(), parts[1].trim());
            saveData();
            sender.sendMessage(mk("[ADMIN] Motive set for: " + parts[0].trim(), NamedTextColor.GREEN));
            return true;
        }
    }

    // ─── /listmotives ───────────────────────────────────────
    class ListMotivesCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            sender.sendMessage(mk("━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GOLD));
            sender.sendMessage(Component.text("  MOTIVES", NamedTextColor.GOLD).decoration(TextDecoration.BOLD, true));
            sender.sendMessage(mk("━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GOLD));
            if (motives.isEmpty()) sender.sendMessage(mk("  None set yet.", NamedTextColor.GRAY));
            else motives.forEach((u, m) -> {
                sender.sendMessage(mk("✦ " + u + ":", NamedTextColor.YELLOW));
                sender.sendMessage(mk("  " + m, NamedTextColor.WHITE));
            });
            sender.sendMessage(mk("━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GOLD));
            return true;
        }
    }

    // ─── /motive ────────────────────────────────────────────
    class MotiveCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (motives.isEmpty()) { sender.sendMessage(mk("⚠ No motives set. Use /setmotive first.", NamedTextColor.RED)); return true; }
            int sent = 0, missing = 0;
            for (Player p : Bukkit.getOnlinePlayers()) {
                String ult = ultimates.get(p.getName());
                if (ult == null) { missing++; continue; }
                String motive = motives.get(ult);
                if (motive == null) { missing++; p.sendMessage(mk("⚠ No motive set for your Ultimate.", NamedTextColor.RED)); continue; }
                giveMotiveBook(p, ult, motive);
                sent++;
            }
            monokumaAnnounce("Upupu~ A new killing motive has been revealed! Each of you has received a personal motive. Your motive is for your eyes only~");
            sender.sendMessage(mk("[ADMIN] Motives sent: " + sent + " players. Missing: " + missing + ".", NamedTextColor.GOLD));
            return true;
        }
        private void giveMotiveBook(Player p, String ultimate, String motive) {
            ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
            BookMeta meta  = (BookMeta) Objects.requireNonNull(book.getItemMeta());
            meta.setTitle("Killing Motive");
            meta.setAuthor("Monokuma");
            meta.addPages(Component.text().append(Component.text("━━━━━━━━━━━━━━━\n", NamedTextColor.DARK_GRAY))
                .append(Component.text("KILLING\nMOTIVE\n", NamedTextColor.DARK_RED).decoration(TextDecoration.BOLD, true))
                .append(Component.text("━━━━━━━━━━━━━━━\n\n", NamedTextColor.DARK_GRAY))
                .append(Component.text("For: ", NamedTextColor.BLACK).decoration(TextDecoration.BOLD, true))
                .append(Component.text(p.getName() + "\n\n", NamedTextColor.DARK_BLUE))
                .append(Component.text("Upupu~\nRead on...", NamedTextColor.BLACK).decoration(TextDecoration.ITALIC, true)).build());
            meta.addPages(Component.text().append(Component.text("YOUR MOTIVE\n━━━━━━━━━━\n\n", NamedTextColor.DARK_RED).decoration(TextDecoration.BOLD, true))
                .append(Component.text(motive, NamedTextColor.BLACK)).build());
            book.setItemMeta(meta);
            p.getInventory().addItem(book);
            p.playSound(p.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1f, 0.8f);
        }
    }

    // ─── /givecoin <player> <amount> ────────────────────────
    class GiveCoinCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (args.length < 2) { sender.sendMessage(mk("Usage: /givecoin <player> <amount>", NamedTextColor.RED)); return true; }
            Player t = Bukkit.getPlayer(args[0]);
            if (t == null) { sender.sendMessage(mk("⚠ Player not found.", NamedTextColor.RED)); return true; }
            try {
                int amount = Integer.parseInt(args[1]);
                adjustCoins(t, amount);
                sender.sendMessage(mk("[ADMIN] Gave " + amount + " coins to " + t.getName(), NamedTextColor.GREEN));
            } catch (NumberFormatException e) { sender.sendMessage(mk("⚠ Invalid amount.", NamedTextColor.RED)); }
            return true;
        }
    }

    // ─── /coins ─────────────────────────────────────────────
    class CoinsCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
            p.sendMessage(mk("✦ Your Monocoins: " + coins.getOrDefault(p.getName(), 0), TextColor.fromHexString("#FFD700")));
            return true;
        }
    }

    // ─── /setmono, /setroulette, /setshop ───────────────────
    class SetMonoCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player p)) return true;
            Block b = p.getTargetBlockExact(5);
            if (b == null) { p.sendMessage(mk("⚠ Look at the machine block.", NamedTextColor.RED)); return true; }
            monoMomoLocation = blockLocStr(b.getLocation());
            saveData();
            p.sendMessage(mk("[ADMIN] MonoMono Machine set at " + monoMomoLocation, NamedTextColor.GREEN));
            return true;
        }
    }
    class SetRouletteCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player p)) return true;
            Block b = p.getTargetBlockExact(5);
            if (b == null) { p.sendMessage(mk("⚠ Look at the machine block.", NamedTextColor.RED)); return true; }
            rouletteLocation = blockLocStr(b.getLocation());
            saveData();
            p.sendMessage(mk("[ADMIN] Roulette Machine set at " + rouletteLocation, NamedTextColor.GREEN));
            return true;
        }
    }
    class SetShopCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player p)) return true;
            Block b = p.getTargetBlockExact(5);
            if (b == null) { p.sendMessage(mk("⚠ Look at the machine block.", NamedTextColor.RED)); return true; }
            shopLocation = blockLocStr(b.getLocation());
            saveData();
            p.sendMessage(mk("[ADMIN] Coin Shop set at " + shopLocation, NamedTextColor.GREEN));
            return true;
        }
    }

    // ─── /hope, /sethope ────────────────────────────────────
    class HopeCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            sender.sendMessage(mk("━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GOLD));
            sender.sendMessage(mk("  Hope:    " + hopeScore, NamedTextColor.AQUA));
            sender.sendMessage(mk("  Despair: " + despairScore, NamedTextColor.RED));
            sender.sendMessage(mk("  Net:     " + (hopeScore - despairScore), (hopeScore >= despairScore ? NamedTextColor.GREEN : NamedTextColor.RED)));
            sender.sendMessage(mk("━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GOLD));
            return true;
        }
    }
    class SetHopeCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (args.length < 2) { sender.sendMessage(mk("Usage: /sethope <hope> <despair>", NamedTextColor.RED)); return true; }
            try {
                hopeScore    = Integer.parseInt(args[0]);
                despairScore = Integer.parseInt(args[1]);
                saveData();
                sender.sendMessage(mk("[ADMIN] Hope=" + hopeScore + " Despair=" + despairScore, NamedTextColor.GREEN));
            } catch (NumberFormatException e) { sender.sendMessage(mk("⚠ Numbers only.", NamedTextColor.RED)); }
            return true;
        }
    }

    // ─── /resetgame ─────────────────────────────────────────
    class ResetGameCommand implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            roles.clear(); ultimates.clear(); coins.clear(); backstories.clear();
            motives.clear(); monoUses.clear(); rouletteUses.clear();
            hopeScore=0; despairScore=0; chapterNumber=0; gameRunning=false;
            currentPhase="WAITING"; phaseCountdown=0; nightActive=false;
            saveData();
            sender.sendMessage(mk("[ADMIN] Game fully reset.", NamedTextColor.GREEN));
            return true;
        }
    }

    // ========================================================
    // DATA SAVING & LOADING
    // ========================================================
    // ========================================================
    // PUBLIC GETTERS — used by DgnPlaceholders
    // ========================================================
    public String  getUltimate(String name)    { return ultimates.getOrDefault(name, "Ultimate ???"); }
    public String  getRole(String name)         { return roles.getOrDefault(name, "STUDENT"); }
    public int     getCoins(String name)        { return coins.getOrDefault(name, 0); }
    public String  getCurrentPhase()            { return currentPhase; }
    public int     getPhaseCountdown()          { return phaseCountdown; }
    public int     getChapterNumber()           { return chapterNumber; }
    public int     getHopeScore()               { return hopeScore; }
    public int     getDespairScore()            { return despairScore; }
    public boolean isGameRunning()              { return gameRunning; }

    private void loadData() {
        dataFile = new File(getDataFolder(), "coredata.yml");
        if (!dataFile.exists()) { try { dataFile.createNewFile(); } catch (IOException e) { getLogger().severe(e.getMessage()); } }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

        loadMap("ultimates",  ultimates);
        loadMap("roles",      roles);
        loadMap("backstories",backstories);
        loadMap("motives",    motives);
        loadIntMap("coins",   coins);

        hopeScore            = dataConfig.getInt("game.hope",    0);
        despairScore         = dataConfig.getInt("game.despair", 0);
        chapterNumber        = dataConfig.getInt("game.chapter", 0);
        gameRunning          = dataConfig.getBoolean("game.running", false);
        currentPhase         = dataConfig.getString("game.phase",   "WAITING");
        investigationMinutes = dataConfig.getInt("game.invMinutes", 45);
        nightMinutes         = dataConfig.getInt("game.nightMinutes", 30);
        monoMomoLocation     = dataConfig.getString("machines.mono");
        rouletteLocation     = dataConfig.getString("machines.roulette");
        shopLocation         = dataConfig.getString("machines.shop");

        getLogger().info("CorePlugin data loaded.");
    }

    private void saveData() {
        if (dataConfig == null) return;
        saveMap("ultimates",  ultimates);
        saveMap("roles",      roles);
        saveMap("backstories",backstories);
        saveMap("motives",    motives);
        saveIntMap("coins",   coins);

        dataConfig.set("game.hope",         hopeScore);
        dataConfig.set("game.despair",       despairScore);
        dataConfig.set("game.chapter",       chapterNumber);
        dataConfig.set("game.running",       gameRunning);
        dataConfig.set("game.phase",         currentPhase);
        dataConfig.set("game.invMinutes",    investigationMinutes);
        dataConfig.set("game.nightMinutes",  nightMinutes);
        dataConfig.set("machines.mono",      monoMomoLocation);
        dataConfig.set("machines.roulette",  rouletteLocation);
        dataConfig.set("machines.shop",      shopLocation);

        try { dataConfig.save(dataFile); } catch (IOException e) { getLogger().severe(e.getMessage()); }
    }

    private void loadMap(String key, Map<String, String> map) {
        var sec = dataConfig.getConfigurationSection(key);
        if (sec != null) sec.getKeys(false).forEach(k -> map.put(k, dataConfig.getString(key + "." + k)));
    }
    private void saveMap(String key, Map<String, String> map) {
        map.forEach((k, v) -> dataConfig.set(key + "." + k, v));
    }
    private void loadIntMap(String key, Map<String, Integer> map) {
        var sec = dataConfig.getConfigurationSection(key);
        if (sec != null) sec.getKeys(false).forEach(k -> map.put(k, dataConfig.getInt(key + "." + k)));
    }
    private void saveIntMap(String key, Map<String, Integer> map) {
        map.forEach((k, v) -> dataConfig.set(key + "." + k, v));
    }
}
