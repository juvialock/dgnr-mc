package com.danganronpa;

import org.bukkit.entity.Player;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

// ============================================================
//  DgnPackets — server-side packet sender
//
//  Sends plugin messages from the Paper server to the
//  DanganronpaCraft Fabric mod running on each client.
//
//  FORMAT: Each packet is a byte array where strings are
//  written as: VarInt length + UTF-8 bytes  (compatible with
//  Fabric's PacketByteBuf.readString() on the client side)
//  Ints are 4-byte big-endian (compatible with readInt())
//  Booleans are 1 byte (compatible with readBoolean())
//
//  CHANNELS — must match PacketChannels.java in the Fabric mod
// ============================================================
public final class DgnPackets {

    // Channel names — must exactly match the Fabric mod's PacketChannels
    public static final String CH_GAME_STATE       = "danganronpacraft:game_state";
    public static final String CH_PLAYER_STATE     = "danganronpacraft:player_state";
    public static final String CH_BODY_DISCOVERY   = "danganronpacraft:body_discovery";
    public static final String CH_DEFENCE_CHALLENGE= "danganronpacraft:defence_challenge";
    public static final String CH_DEFENCE_RESULT   = "danganronpacraft:defence_result";
    public static final String CH_MONOKUMA_ANNOUNCE= "danganronpacraft:monokuma_announce";
    public static final String CH_DOSSIER_UPDATE   = "danganronpacraft:dossier_update";
    public static final String CH_WEAPON_STATE     = "danganronpacraft:weapon_state";

    private final CorePlugin plugin;

    public DgnPackets(CorePlugin plugin) {
        this.plugin = plugin;
    }

    // ── Registration ──────────────────────────────────────────

    /** Call this in CorePlugin.onEnable() */
    public void registerChannels() {
        var m = plugin.getServer().getMessenger();
        m.registerOutgoingPluginChannel(plugin, CH_GAME_STATE);
        m.registerOutgoingPluginChannel(plugin, CH_PLAYER_STATE);
        m.registerOutgoingPluginChannel(plugin, CH_BODY_DISCOVERY);
        m.registerOutgoingPluginChannel(plugin, CH_DEFENCE_CHALLENGE);
        m.registerOutgoingPluginChannel(plugin, CH_DEFENCE_RESULT);
        m.registerOutgoingPluginChannel(plugin, CH_MONOKUMA_ANNOUNCE);
        m.registerOutgoingPluginChannel(plugin, CH_DOSSIER_UPDATE);
        m.registerOutgoingPluginChannel(plugin, CH_WEAPON_STATE);
    }

    /** Call this in CorePlugin.onDisable() */
    public void unregisterChannels() {
        plugin.getServer().getMessenger().unregisterOutgoingPluginChannel(plugin);
    }

    // ── Packet senders ────────────────────────────────────────

    /**
     * Broadcasts current game state (phase, countdown, living, chapter,
     * hope, despair) to ALL online players. Call every ~5 seconds.
     */
    public void broadcastGameState(String phase, int countdown, int living,
                                    int chapter, int hope, int despair) {
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            DataOutputStream out    = new DataOutputStream(b);
            writeString(out, phase);
            out.writeInt(countdown);
            out.writeInt(living);
            out.writeInt(chapter);
            out.writeInt(hope);
            out.writeInt(despair);
            byte[] data = b.toByteArray();
            for (Player p : plugin.getServer().getOnlinePlayers())
                p.sendPluginMessage(plugin, CH_GAME_STATE, data);
        } catch (IOException ignored) {}
    }

    /**
     * Sends this specific player's personal state (role, ultimate, coins).
     * Call when their state changes or when they join.
     */
    public void sendPlayerState(Player player, String role, String ultimate, int coins) {
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            DataOutputStream out    = new DataOutputStream(b);
            writeString(out, role);
            writeString(out, ultimate);
            out.writeInt(coins);
            player.sendPluginMessage(plugin, CH_PLAYER_STATE, b.toByteArray());
        } catch (IOException ignored) {}
    }

    /**
     * Triggers the full-screen body discovery overlay on ALL players.
     */
    public void broadcastBodyDiscovery(String victimName) {
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            DataOutputStream out    = new DataOutputStream(b);
            writeString(out, victimName);
            byte[] data = b.toByteArray();
            for (Player p : plugin.getServer().getOnlinePlayers())
                p.sendPluginMessage(plugin, CH_BODY_DISCOVERY, data);
        } catch (IOException ignored) {}
    }

    /**
     * Shows the defence mini-game overlay to ONE player (the target of a murder attempt).
     */
    public void sendDefenceChallenge(Player player, String code, int seconds) {
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            DataOutputStream out    = new DataOutputStream(b);
            writeString(out, code);
            out.writeInt(seconds);
            player.sendPluginMessage(plugin, CH_DEFENCE_CHALLENGE, b.toByteArray());
        } catch (IOException ignored) {}
    }

    /**
     * Tells the client whether the defence succeeded or failed.
     */
    public void sendDefenceResult(Player player, boolean success) {
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            DataOutputStream out    = new DataOutputStream(b);
            out.writeBoolean(success);
            player.sendPluginMessage(plugin, CH_DEFENCE_RESULT, b.toByteArray());
        } catch (IOException ignored) {}
    }

    /**
     * Shows the Monokuma notification widget on ALL players.
     */
    public void broadcastMonokumaAnnounce(String message) {
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            DataOutputStream out    = new DataOutputStream(b);
            writeString(out, message);
            byte[] data = b.toByteArray();
            for (Player p : plugin.getServer().getOnlinePlayers())
                p.sendPluginMessage(plugin, CH_MONOKUMA_ANNOUNCE, data);
        } catch (IOException ignored) {}
    }

    /**
     * Sends a player's full dossier (evidence list) to their client.
     * The Handbook's Dossier tab will display these entries.
     * Each entry is a plain string. Autopsy entries are prefixed "AUTOPSY:"
     * so the client can render them with special red formatting.
     */
    public void sendDossierUpdate(Player player, List<String> entries) {
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            DataOutputStream out    = new DataOutputStream(b);
            out.writeInt(entries.size());
            for (String e : entries) writeString(out, e);
            player.sendPluginMessage(plugin, CH_DOSSIER_UPDATE, b.toByteArray());
        } catch (IOException ignored) {}
    }

    /**
     * Updates the weapon reticle state on ONE player's client.
     */
    public void sendWeaponState(Player player, boolean holding, boolean targetInRange) {
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            DataOutputStream out    = new DataOutputStream(b);
            out.writeBoolean(holding);
            out.writeBoolean(targetInRange);
            player.sendPluginMessage(plugin, CH_WEAPON_STATE, b.toByteArray());
        } catch (IOException ignored) {}
    }

    // ── Byte writing helpers ──────────────────────────────────

    /**
     * Writes a string in Minecraft's PacketByteBuf format:
     * VarInt byte count, then UTF-8 bytes.
     * This is exactly what the Fabric client reads with buf.readString().
     */
    private static void writeString(DataOutputStream out, String s) throws IOException {
        byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
        writeVarInt(out, bytes.length);
        out.write(bytes);
    }

    /** Writes an integer as a Minecraft VarInt (1-5 bytes, little-endian groups of 7 bits). */
    private static void writeVarInt(DataOutputStream out, int value) throws IOException {
        while ((value & 0xFFFFFF80) != 0L) {
            out.writeByte((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        out.writeByte(value & 0x7F);
    }
}
